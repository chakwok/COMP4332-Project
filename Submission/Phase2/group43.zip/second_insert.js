db = db.getSiblingDB("courses")
//straight forward; following the database design format, if necessary read the report for more details
db.course.insert(
{
	Cname:"Introduction to Natural Language Processing",
	Course_Code: "COMP 4221",
	Units: "3",
	PreRequisite: "ELEC 2600 OR IELM 2510 OR MATH 2411 OR MATH 2421 OR MATH 2431",
	EXCLUSION: "COMP 5221",
	DESCRIPTION: "Human language technology for text and spoken language. Machine learning, syntactic parsing, semantic interpretation, and context-based approaches to machine translation, text mining, and web search.",
	TimeList:[
		{
		timeslot: new Date("2018-01-26T14:00:00Z"),
		SectionList:[
			{
			section:"L1 (1912)",
			date_time:"Mo 09:00AM - 11:50AM",
			room:"Rm 2406, Lift 17-18 (76)",
			instructor:"WU, Dekai",
			quota:"40",
			enrol:"40",
			available:"0",
			wait:"13",
			Remarks: "> Co-list with COMP 5221"
			},
			{
			section:"T1 (1913)",
			date_time:"We 09:30AM - 10:20AM",
			room:"Rm 4503, Lift 25-26 (64)",
			instructor:"WU, Dekai",
			quota:"40",
			enrol:"40",
			available:"0",
			wait:"13"
			}
			]
		},
		{
		timeslot: new Date("2018-02-01T11:00:00Z"),
		SectionList:[
			{
			section:"L1 (1912)",
			date_time:"Mo 09:00AM - 11:50AM",
			room:"Rm 2406, Lift 17-18 (76)",
			instructor:"WU, Dekai",
			quota:"40",
			enrol:"40",
			available:"0",
			wait:"14",
			Remarks: "> Co-list with COMP 5221"
			},
			{
			section:"T1 (1913)",
			date_time:"We 09:30AM - 10:20AM",
			room:"Rm 4503, Lift 25-26 (64)",
			instructor:"WU, Dekai",
			quota:"40",
			enrol:"40",
			available:"0",
			wait:"14"
			}
			]
		},
		{
		timeslot: new Date("2018-02-01T11:30:00Z"),
		SectionList:[
			{
			section:"L1 (1912)",
			date_time:"Mo 09:00AM - 11:50AM",
			room:"Rm 2406, Lift 17-18 (76)",
			instructor:"WU, Dekai",
			quota:"40",
			enrol:"40",
			available:"0",
			wait:"14",
			Remarks: "> Co-list with COMP 5221"
			},
			{
			section:"T1 (1913)",
			date_time:"We 09:30AM - 10:20AM",
			room:"Rm 4503, Lift 25-26 (64)",
			instructor:"WU, Dekai",
			quota:"40",
			enrol:"40",
			available:"0",
			wait:"14"
			}
			]
		},
		{
		timeslot: new Date("2018-02-03T12:00:00Z"),
		SectionList:[
			{
			section:"L1 (1912)",
			date_time:"Mo 09:00AM - 11:50AM",
			room:"Rm 2406, Lift 17-18 (76)",
			instructor:"WU, Dekai",
			quota:"40",
			enrol:"40",
			available:"0",
			wait:"21",
			Remarks: "> Co-list with COMP 5221"
			},
			{
			section:"T1 (1913)",
			date_time:"We 09:30AM - 10:20AM",
			room:"Rm 4503, Lift 25-26 (64)",
			instructor:"WU, Dekai",
			quota:"40",
			enrol:"40",
			available:"0",
			wait:"21"
			}
			]
		}
		]
}
)

