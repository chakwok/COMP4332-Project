db = db.getSiblingDB("courses")
//straight forward; following the database design format, if necessary read the report for more details
db.course.insert(
{
	Cname:"Big Data Mining and Management",
	Course_Code: "COMP 4332",
	Units: "3",
	PreRequisite: "COMP 4211 OR COMP 4331 OR ISOM 3360",
	CO_LIST_WITH: "RMBI 4310",
	DESCRIPTION: "This course will expose students to new and practical issues of real world mining and managing big data. Data mining and management is to effectively support storage, retrieval, and extracting implicit, previously unknown, and potentially useful knowledge from data. This course will place emphasis on two parts. The first part is big data issues such as mining and managing on distributed data, sampling on big data and using some cloud computing techniques on big data. The second part is applications of the techniques learnt on areas such as business intelligence, science and engineering, which aims to uncover facts and patterns in large volumes of data for decision support. This course builds on basic knowledge gained in the introductory data-mining course, and explores how to more effectively mine and manage large volumes of real-world data and to tap into large quantities of data. Working on real world data sets, students will experience all steps of a data-mining and management project, beginning with problem definition and data selection, and continuing through data management, data exploration, data transformation, sampling, portioning, modeling, and assessment.",
	TimeList:[
		{
		timeslot: new Date("2018-01-26T14:00:00Z"),
		SectionList:[
			{
			section:"L1 (1918)",
			date_time:"WeFr 01:30PM - 02:50PM",
			room:"G010, CYT Bldg (140)",
			instructor:"WONG, Raymond Chi Wing",
			quota:"65",
			enrol:"64",
			available:"1",
			wait:"4"
			},
			{
			section:"T1 (1919)",
			date_time:"Tu 06:00PM - 06:50PM",
			room:"Rm 4619, Lift 31-32 (126)",
			instructor:"WONG, Raymond Chi Wing",
			quota:"65",
			enrol:"64",
			available:"1",
			wait:"4"
			}
			]
		},
		{
		timeslot: new Date("2018-02-01T11:00:00Z"),
		SectionList:[
			{
			section:"L1 (1918)",
			date_time:"WeFr 01:30PM - 02:50PM",
			room:"G010, CYT Bldg (140)",
			instructor:"WONG, Raymond Chi Wing",
			quota:"75",
			enrol:"70",
			available:"5",
			wait:"4"
			},
			{
			section:"T1 (1919)",
			date_time:"Tu 06:00PM - 06:50PM",
			room:"Rm 4619, Lift 31-32 (126)",
			instructor:"WONG, Raymond Chi Wing",
			quota:"75",
			enrol:"70",
			available:"5",
			wait:"4"
			}
			]
		},
		{
		timeslot: new Date("2018-02-01T11:30:00Z"),
		SectionList:[
			{
			section:"L1 (1918)",
			date_time:"WeFr 01:30PM - 02:50PM",
			room:"G010, CYT Bldg (140)",
			instructor:"WONG, Raymond Chi Wing",
			quota:"75",
			enrol:"71",
			available:"4",
			wait:"3"
			},
			{
			section:"T1 (1919)",
			date_time:"Tu 06:00PM - 06:50PM",
			room:"Rm 4619, Lift 31-32 (126)",
			instructor:"WONG, Raymond Chi Wing",
			quota:"75",
			enrol:"71",
			available:"4",
			wait:"3"
			}
			]
		},
		{
		timeslot: new Date("2018-02-03T12:00:00Z"),
		SectionList:[
			{
			section:"L1 (1918)",
			date_time:"WeFr 01:30PM - 02:50PM",
			room:"G010, CYT Bldg (140)",
			instructor:"WONG, Raymond Chi Wing",
			quota:"75",
			enrol:"70",
			available:"5",
			wait:"4"
			},
			{
			section:"T1 (1919)",
			date_time:"Tu 06:00PM - 06:50PM",
			room:"Rm 4619, Lift 31-32 (126)",
			instructor:"WONG, Raymond Chi Wing",
			quota:"75",
			enrol:"75",
			available:"0",
			wait:"4"
			}
			]
		}
		]
}
)