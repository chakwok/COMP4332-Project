//get the essential information using python/ js.
//the search query will then be applied as follows

db = db.getSiblingDB("courses");

cursor=db.course.aggregate(
[
	//match the course according to the specified requirement, we are using regular expression to check if the Cname in the database contains the phrase(s) in the query
	{$match: {Cname: /A/i}},
	{$unwind:"$TimeList"},
	{$project: {Course_Code:1, Cname:1, Units:1, _id:0, "TimeList.timeslot":1, "TimeList.SectionList":1}},
	//to retrieve the section details in TimeList which has the largest timeslot, we reorder it in descending order
	//by using the $first operation we get the timeslot with latest date, which contains the most updated information
	//$first is a feature that returns the value that results from applying an expression to the first document in a group of documents that share the same group by key. Only meaningful when documents are in a defined order.
	{$sort:{Cname:-1,"TimeList.timeslot":-1}},
	{$group:{
		"_id": "$Course_Code",
		"CourseTitle": {"$first": "$Cname"},
		"NoOfUnits": {"$first": "$Units"},
		"TimeSlot": {"$first": "$TimeList.timeslot"},
		"SectionList": {"$first": "$TimeList.SectionList"}
		}
	},
	//output in the return format as required
	{$project: {_id:1, CourseTitle:1, NoOfUnits:1, MatchedTimeSlot:1, "SectionList.section":1, "SectionList.date_time":1, "SectionList.quota":1, "SectionList.enrol":1, "SectionList.available":1, "SectionList.wait":1}},
	{$sort: {_id:1} }
]
);

while ( cursor.hasNext() ) {
   printjson( cursor.next() );
}