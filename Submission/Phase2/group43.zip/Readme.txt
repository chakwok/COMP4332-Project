1. 
Group 43 
Members:
Kwok Chun Ho Andy	
Leung Wai Hin


2 & 3.
Phase2-report
  - The hardcopy report describing 1. the database format 2. NoSQL insertion Script 3. NoSQL query Script
Readme.txt
  - this doc
first_insert.js
  - the script for 1 insertion 
second_insert.js
  - the script for another insertion  
first_search.js
  - the script for 5.3.1 Course Search by Keyword
second_search.js
  - the script for 5.3.2 Course Search by Wait List Size



4. 
N/A

*please create database and collection before running the js by using 
use courses
and 
db.createCollection("course")
notice the database has an "s" in the end while the collection does not