1. 
Group 43 
Members:
Kwok Chun Ho Andy	
Leung Wai Hin


2 & 3.
Phase2-report
  - The hardcopy report describing 1. the database format 2. NoSQL insertion Script 3. NoSQL query Script
Readme.txt
  - this doc
Phase4.py
  - the python source code for the main program


4. 
Python Phase4.py

*the device should have mongodb module installed, and hosting a mongodb server at the default port
*please follow the previous stage to create the database and collection properly, notice that the type of some attribute should be changed from string to number, including all "Units", "quota", "available", "wait"