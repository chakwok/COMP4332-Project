Group 43
Phase1_stubs.py
The Phase1_stubs.py contains a main function that allows that user to perform the 5 implemented functions 
python  Phase1_stubs.py
n/a